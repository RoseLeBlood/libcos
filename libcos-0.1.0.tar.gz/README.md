# libcos
A simple lib C for osdev
