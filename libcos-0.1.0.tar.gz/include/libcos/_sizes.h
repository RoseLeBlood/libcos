#ifndef _STDC_MACHINE__TYPES_H_
#define _STDC_MACHINE__TYPES_H_

#ifndef __CHAR_BIT__
# define __CHAR_BIT__                   8
#endif

#ifndef __SIZEOF_SHORT__
# define __SIZEOF_SHORT__               sizeof(short)
#endif

#endif