#ifndef __STDC_STDBOOL_H_
#define __STDC_STDBOOL_H_

#ifndef _Bool
#define _Bool   char
#endif

#define bool                                    _Bool
#define true                                    1
#define false                                   0
#define __bool_true_false_are_defined   1


#endif