#ifndef _STDC_INTTYPES_H_
#define _STDC_INTTYPES_H_

#include "stdint.h"

#endif