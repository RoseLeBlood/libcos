#ifndef	_HASH__H
#define	_HASH__H


#include "hash/adler32.h"
#include "hash/crc.h"

#endif