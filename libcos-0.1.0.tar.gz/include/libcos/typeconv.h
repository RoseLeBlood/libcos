#ifndef KLIBC_TYPECONV_H
#define KLIBC_TYPECONV_H

unsigned char bcd2bin(unsigned char);

#endif